// scripts.js
// Theme Toggle
document.getElementById('theme-toggle')?.addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
});

// Search Function
document.querySelector('form').addEventListener('submit', (e) => {
    e.preventDefault();
    const query = document.getElementById('searchInput').value.toLowerCase();
    const cards = document.querySelectorAll('.card');
    cards.forEach(card => {
        const title = card.querySelector('.card-title').textContent.toLowerCase();
        card.parentElement.style.display = title.includes(query) ? 'block' : 'none';
    });
});

// Load More Function
const loadMoreBtn = document.getElementById('load-more');
const sections = document.querySelectorAll('section');
sections.forEach(section => {
    const cards = section.querySelectorAll('.col-md-3');
    for (let i = 8; i < cards.length; i++) {
        cards[i].style.display = 'none';
    }
});
loadMoreBtn.addEventListener('click', () => {
    sections.forEach(section => {
        const hiddenCards = section.querySelectorAll('.col-md-3[style*="display: none"]');
        for (let i = 0; i < 8 && i < hiddenCards.length; i++) {
            hiddenCards[i].style.display = 'block';
        }
    });
    if (!document.querySelector('.col-md-3[style*="display: none"]')) {
        loadMoreBtn.style.display = 'none';
    }
});